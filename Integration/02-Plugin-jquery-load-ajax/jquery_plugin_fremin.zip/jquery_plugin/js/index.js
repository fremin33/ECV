$(document).ready(function () {
    $('#myMenu a').loadWithAjax();
});